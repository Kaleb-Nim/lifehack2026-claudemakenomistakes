repo: Kaleb-Nim/lifehack2026-claudemakenomistakes
branch: main
path: apps/merchant

## Last sync
date: 2026-08-29T08:56:41Z

### Updated in this project
- Read `apps/merchant` (Onboarding.tsx, merchant-data.ts, README/AGENTS) and `docs/post-mentor-team-decision-2026-08-29.md` for context on the hardcoded-demo merchant flow.
- Built `Merchant Payments.dc.html`, a new merchant-side payments view (today's collections, per-outlet feed, order detail, payout, payment setup) in the same Modernist design system as the onboarding page.
- Copied the `modernist` design-system bundle (styles.css, _ds_bundle.js, manifest) used by the onboarding frames.

## Screen map
| Project screen | Repo source |
| --- | --- |
| Merchant Payments.dc.html | apps/merchant/lib/merchant-data.ts, apps/merchant/components/Onboarding.tsx (data/style reference) |
| Merchant Onboarding v3.dc.html / FrameQuiet2.dc.html (pre-existing) | apps/merchant/components/Onboarding.tsx, apps/merchant/lib/merchant-data.ts |
