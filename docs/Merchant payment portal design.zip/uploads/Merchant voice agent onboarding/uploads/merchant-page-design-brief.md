# Design brief — Merchant onboarding page (voice agent)

Self-contained. Everything a designer needs to design this one page is in this document; nothing else needs to be read.

## 1. What this is

A single web page where a small electronics-shop owner onboards their shop onto a shared AI shopping agent by **talking to a voice agent** while dropping whatever they have (a spreadsheet, photos of the shelf, a store URL) into the same screen. The agent reads the material, confirms what it understood out loud, asks a handful of laptop-shop-specific questions, and finishes with the shop's products "readable" by the shopping agent.

It is **one conversational screen**, not a multi-step wizard and not a dashboard. There is no admin area, no analytics, no orders list, no settings. The page begins empty and ends with the shop live. That is the whole product surface for the merchant.

Context: 24-hour hackathon (LifeHack 2026, Visa Digital Payments track). The page is for a **recorded demo video** first; it will be hardcoded, so every state and every line of copy below is fixed and can be designed literally.

## 2. Who it is for

- **Primary:** an SME electronics shop owner in Singapore — think a laptop stall in Sim Lim Square with one or two counters. Not technical. Has a messy Excel stock list, an out-of-date Shopify site he never updates, and a phone full of photos. Wants this over in a few minutes. Will do it on a laptop at the counter, possibly with the phone for photos.
- **Secondary audience:** hackathon judges from Visa watching the video. They need to *see* three things: the merchant uploads anything with zero effort; the agent turns it into structured product data; the agent asks smart, category-aware questions rather than presenting a form.

Design mood the owner should feel: "I just talked to someone who knows laptop shops, and it's done."

## 3. The core idea to design around

**Voice first, terminal beside it.** The owner never fills a form. The agent asks, the owner speaks. The visual job of the page is to make the agent's *understanding* visible while the conversation happens: what it locked in, what it is reading, what it is unsure about.

The sketch we are working from (hand-drawn, four regions):

```
┌──────────────────────────────────────────────────────────────────┐
│  KEY DECISIONS (left)      ●  VOICE ORB  ●      CONTEXT (right)  │
│  spoken log — one line     waveform + mic       files · images · │
│  per fact the agent has    the agent talks      website, one     │
│  locked in                 here; owner's        card per source  │
│                            speech captioned     with status      │
│                                                                  │
├──────────────────────────────────────────────────────────────────┤
│              UPLOAD FILES  /  PASTE URL   (drop bar)             │
└──────────────────────────────────────────────────────────────────┘
```

- **Voice orb (centre)** — the hero. Pulses/animates when the agent speaks; a different "listening" state when the owner speaks. The owner's speech is captioned live beneath it. The agent's current line is shown as text too (accessibility, and the video needs readable words).
- **Key decisions (left)** — a growing list of short lines, appended in real time as the agent locks something in. Three line states: locked (`✓`), open question (`?`), conflict/flag (`!`). This is the agent's "memory" made visible. It never scrolls away during the demo (≈16 lines max).
- **Context (right)** — one card per ingested source (spreadsheet, website, photos). Each card has a `reading…` state with a progress bar (held ~4 s), then a result summary and a few monospace "terminal" lines of what was extracted. This is where the "it actually read my stuff" feeling comes from.
- **Drop bar (bottom)** — one wide target: drag files here, or paste a URL. Always present. At the very end it turns into a single **Go live** button.
- **Quick-reply pills** — appear under the orb only when the agent asks an either/or question (twice in the flow). Tapping one is the only click besides the drop bar.

Desktop-first (the owner is at a laptop at the counter, and the video is 16:9). A phone layout is nice-to-have, not required for the demo.

## 4. The flow, state by state

Total ≈ 2:30. Design a frame for each state; the copy is final.

### State A — Empty / invite
Orb idle. Left and right columns empty (design their empty states — light hints, no lorem). Drop bar reads: *"Drop a spreadsheet, photos, or paste your store link. Or just tell me about your shop."*

Agent says: *"Hi, I'm the agent for electronics shops. Tell me about your shop, or drop anything you have — a price list, photos of your shelves, your website. I'll do the sorting."*

### State B — Owner's free-form brain-dump (the "initial input")
Orb in listening state; caption streams the owner's words:

> *"Okay. My shop is Ah Seng Electronics, we're in Sim Lim Square, third floor. We mainly sell laptops — ASUS, Lenovo, Acer, some MacBooks — and the usual accessories, docks, mouse, SSD, bags. We have another counter at Jurong Point. I have a Shopify site but it's not really updated. I'll just send you my stock list and some photos of the shelf."*

Left column fills **while he is still talking**:
```
✓ Shop: Ah Seng Electronics · Sim Lim Square
✓ Category guess: Electronics → Laptops & accessories
✓ Outlets: Bugis (Sim Lim) · Jurong Point
? Website: Shopify (owner says outdated)
```
Agent replies: *"Got it — Ah Seng Electronics, laptops and accessories, two counters. Send the stock list and photos whenever you're ready, and paste the Shopify link too even if it's old. I'll cross-check them."*

### State C — Uploads landing (three context cards appear one after another)

1. **Spreadsheet card** — `stocklist_aug.xlsx` → `reading…` → **11 products · 2 outlets · 3 headers guessed**
   ```
   sheet "Aug" · 11 rows
   col B "Item"   → product name
   col C "SLS"    → stock @ Bugis   (guessed: Sim Lim Square)
   col D "JP"     → stock @ Jurong  (guessed: Jurong Point)
   col E "Price"  → price (SGD)
   col F "Remarks"→ notes
   ```
2. **Website card** — `ahseng-electronics.myshopify.com` → `reading…` → **6 products · last updated Mar 2026**
   ```
   /products.json → 6 items
   ⚠ Vivobook 15 listed $949 here, $899 in stocklist
   ⚠ 4 stocklist items not on the site
   ```
3. **Photos card** — 3 thumbnails → `reading…` → **shelf: 5 laptop boxes, 5 price tags · counter: A4 price list (9 items) · signboard: opening hours + promo**
   ```
   IMG_2201  boxes: Vivobook 15, IdeaPad Slim 5, Nitro V 15, MacBook Air M4, Aspire Go 15
             tags: $899 · $1,099 · $1,299 · $1,499 · $649
   IMG_2202  A4 list matches stocklist for 9/11 items
   IMG_2203  "Mon–Sat 11am–8pm · Sun 12–6pm" · "Student promo: $50 off any laptop with matric card"
   ```
Agent (over the cards flipping): *"Reading… Your spreadsheet has eleven items across the two counters. Your Shopify has six, and it's older — a few prices don't match. The shelf photos gave me five laptops with tags, and I can see your opening hours and a student promo on the signboard. Let me confirm a few things."*

Left column appends:
```
✓ 11 products from 3 sources (merged)
! Price conflict: Vivobook 15 — site $949 vs shelf/stocklist $899
! Promo found on signboard: $50 off laptops w/ matric card
```

### State D — Clarifying round 1 (confirm understanding)
Agent: *"First, the basics. I've put you under Electronics, laptops and accessories — eleven products, five of them laptops. Bugis is the main counter and Jurong the second. Your Vivobook 15 is nine-forty-nine on Shopify but eight-ninety-nine on the shelf and in the stock list. Which one is right?"*
Owner: *"Eight-ninety-nine. The website is old, I never update it."*
Agent: *"Okay, I'll trust the stock list and shelf over the website for everything, and flag it whenever they disagree. And the student promo on your sign — fifty off any laptop with a matric card — is that still on?"*
Owner: *"Ya, still on. Only for laptops, not accessories."*

Left column appends:
```
✓ Source priority: stocklist > shelf photo > Shopify
✓ Vivobook 15 = $899
✓ Promo: −$50 laptops only, needs matric card
```
The `!` conflict line from State C should visibly resolve (e.g. becomes `✓`, or is struck and replaced).

### State E — Clarifying round 2 (category-trained questions)
Four short exchanges; the agent asks things only a laptop-shop-aware agent would:

1. Agent: *"Now some laptop-shop things shoppers always ask. One — warranty. Is it the brand's Singapore warranty, or your own shop warranty?"* — Owner: *"Brand warranty, one year local, except MacBook which is Apple's own. We give one week one-to-one exchange for dead-on-arrival."*
2. Agent: *"Two — do you do RAM or SSD upgrades? I saw a sixteen-gig DDR5 stick in your list."* — Owner: *"Yes, upgrades at Bugis only. Jurong don't have the technician."*
3. Agent: *"Three — for the Nitro V, your Jurong stock says zero. If someone at Jurong wants it, can you transfer from Bugis?"* — Owner: *"Can. Usually next day."*
4. Agent: *"Last one — the Aspire Go 15 at six-forty-nine. Is that new or a display set?"* — Owner: *"Display set, last unit. Still got warranty."*

Left column appends:
```
✓ Warranty: brand 1-yr local · MacBook = Apple · 7-day DOA exchange
✓ Services: RAM/SSD upgrades @ Bugis only
✓ Stock transfer Bugis → Jurong, next day
✓ Aspire Go 15 = display set, last unit, warranty intact
```

### State F — Clarifying round 3 (behaviour rules, answered by tapping)
Agent: *"Two quick rules so I represent you properly. If a shopper wants something cheaper than what you stock — say a five-hundred-dollar laptop — should I only show your products, or show the closest and explain why it costs more?"*
Pills under the orb: **Only my products** · **Closest match + explain** → owner taps the second.
Agent: *"And if a shopper wants to reserve or pay, should I let them pay in the chat and pick up, or send them to WhatsApp you?"*
Pills: **Pay in chat, pick up at counter** · **WhatsApp me first** → owner taps the first.

Left column appends:
```
✓ Below-budget: show closest match + explain
✓ Checkout: pay in chat (Visa) → pickup at chosen outlet
```

### State G — Result and go live
The right column gives way to a **listing view**: the eleven products as compact structured cards, with one hero card enlarged — the Vivobook, exactly as the agent will describe it to a shopper:

```
ASUS Vivobook 15 (X1504VA)                         $899   (−$50 student)
15.6" FHD IPS · Intel Core i5-1335U · 16 GB DDR4 · 512 GB SSD · Win 11 Home
Ports: 1× USB-C 3.2 · 2× USB-A · HDMI 1.4 · 3.5 mm · Wi-Fi 6
Weight 1.7 kg · Warranty: ASUS 1-yr local · 7-day DOA exchange
Stock: Bugis 4 · Jurong 2                          Upgrades: RAM/SSD @ Bugis
Good for: students, office work, light photo editing · not for gaming
```

Agent: *"Done. Eleven products are ready, all readable by the shopping agent. Here's how I'll describe your Vivobook to a shopper."*

Drop bar becomes one button: **Go live — shoppers can find Ah Seng Electronics**.

Agent, over the press: *"When someone asks the agent for a laptop for uni under a thousand, Ah Seng Electronics will show up — next to the other shops, with your price, your student promo, and pickup at Bugis or Jurong."*

End of the merchant page. Nothing comes after it on this surface.

## 5. Fixed data (for realistic cards and thumbnails)

**Shop:** Ah Seng Electronics · Bugis — Sim Lim Square #03-12 (main; repairs and upgrades) · Jurong Point #02-41. Hours Mon–Sat 11–8, Sun 12–6. Fake store: `ahseng-electronics.myshopify.com`.

**Eleven products (SGD):**

| Product | Type | Price | Bugis / Jurong |
|---|---|---|---|
| ASUS Vivobook 15 (X1504VA) — i5-1335U, 16 GB, 512 GB | laptop | 899 | 4 / 2 |
| Lenovo IdeaPad Slim 5 14" — Ryzen 7 7730U, 16 GB, 1 TB, OLED | laptop | 1,099 | 3 / 1 |
| Acer Nitro V 15 — i5-13420H, RTX 4050, 16 GB, 512 GB | laptop | 1,299 | 2 / 0 |
| MacBook Air 13" M4 — 16 GB, 256 GB, Midnight | laptop | 1,499 | 2 / 1 |
| Acer Aspire Go 15 — i3-N305, 8 GB, 256 GB (display set) | laptop | 649 | 1 / 0 |
| Anker 7-in-1 USB-C dock | dock | 89 | 6 / 2 |
| Logitech MX Master 3S | mouse | 129 | 5 / 3 |
| Samsung T7 1 TB portable SSD | storage | 139 | 12 / 5 |
| Belkin USB-C cable 2 m 100 W | cable | 29 | 30 / 18 |
| Targus 15.6" laptop backpack | bag | 59 | 7 / 4 |
| Crucial 16 GB DDR5-5600 SO-DIMM | RAM | 79 | 8 / 0 |

**Photo thumbnails:** `IMG_2201.jpg` shelf with five laptop boxes and handwritten price tags · `IMG_2202.jpg` A4 price list taped to a counter · `IMG_2203.jpg` shop signboard with opening hours and a printed promo sheet. Use placeholders that read as those.

## 6. Tone and constraints

- **Copy is final.** Use the lines above verbatim; they are recorded as voice and must match on screen.
- The page must read clearly **in a 16:9 video at 1080p** — type sizes generous, contrast high, the left log legible in a screen recording. Small-text terminal lines are fine if the card summary line is big.
- **No dashboard vocabulary**: no sidebar nav, tabs, KPIs, charts, tables of orders, settings gear, notifications bell. If it looks like an admin panel, it is wrong.
- **No wizard vocabulary**: no numbered steps, progress stepper, "Next"/"Back". Progress is shown by the left log growing and the cards filling.
- Voice is the primary control; the drop bar and the two pill questions are the only pointer interactions. Design hover/press for those three only.
- Show the agent's **uncertainty honestly** — the `?` and `!` states are part of the trust story; don't hide them.
- Icons as line SVGs, not emoji. Keep to one accent colour; the `!` flag colour is the only second hue.
- Timing to design animations against: card `reading…` ≈ 4 s; log lines appear one at a time ~0.6 s apart; orb has three states (idle / speaking / listening).
- The product name is not decided — show it as `[PRODUCT NAME]` in the header; nothing else on the page depends on it.
- Language: English with light Singapore flavour in the owner's captions only; the agent speaks neutral, warm, brief.

## 7. Deliverables wanted from the design pass

1. One desktop frame per state A–G (seven frames), same layout throughout.
2. The three context-card states (reading / done / flagged) as a small component sheet.
3. The orb's three states.
4. The left-log line styles (`✓` / `?` / `!`, and a resolved conflict).
5. The hero product card from State G.

Phone layout, dark mode, and anything after "Go live" are out of scope.
