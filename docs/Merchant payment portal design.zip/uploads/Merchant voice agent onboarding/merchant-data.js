// Fixed demo content for the merchant onboarding page (copy is final, from the brief).
// buildFrames(palette) returns the seven states with per-item colors resolved for that variant.

export function buildFrames(p) {
  const ok = t => ({ mark: "\u2713", text: t, color: p.ink, textColor: p.ink, deco: "none" });
  const q = t => ({ mark: "?", text: t, color: p.mut, textColor: p.mut, deco: "none" });
  const flag = t => ({ mark: "!", text: t, color: p.accent, textColor: p.ink, deco: "none" });
  const struck = t => ({ mark: "\u2713", text: t, color: p.mut, textColor: p.mut, deco: "line-through" });

  const TAG_DONE = { tagFg: p.mut, tagBg: p.chip };
  const TAG_LIVE = { tagFg: p.onAccent, tagBg: p.accent };

  const CARD_SHEET = {
    ...TAG_DONE, file: "stocklist_aug.xlsx", what: "Price list · Excel", status: "11 products", reading: false,
    hasThumbs: false, thumbs: [], hasSummary: true,
    summary: "11 products \u00b7 2 outlets \u00b7 3 headers guessed", hasLines: true,
    lines: 'sheet "Aug" \u00b7 11 rows\ncol C "SLS" \u2192 stock @ Bugis   (guessed: Sim Lim Square)\ncol D "JP"  \u2192 stock @ Jurong  (guessed: Jurong Point)\ncol E "Price" \u2192 price (SGD)   col F "Remarks" \u2192 notes'
  };
  const CARD_SITE = {
    ...TAG_LIVE, file: "ahseng-electronics.myshopify.com", what: "Your store website", status: "2 conflicts", reading: false,
    hasThumbs: false, thumbs: [], hasSummary: true,
    summary: "6 products \u00b7 last updated Mar 2026", hasLines: true,
    lines: "/products.json \u2192 6 items\n\u26a0 Vivobook 15 listed $949 here, $899 in stocklist\n\u26a0 4 stocklist items not on the site"
  };
  const CARD_PHOTOS_READING = {
    ...TAG_LIVE, file: "3 shelf photos", what: "Photos from your phone", status: "reading…", reading: true,
    hasThumbs: true, thumbs: ["IMG_2201", "IMG_2202", "IMG_2203"],
    hasSummary: false, summary: "", hasLines: false, lines: ""
  };
  const CARD_PHOTOS_DONE = {
    ...TAG_DONE, file: "3 shelf photos", what: "Photos from your phone", status: "3 photos read", reading: false,
    hasThumbs: true, thumbs: ["IMG_2201", "IMG_2202", "IMG_2203"], hasSummary: true,
    summary: "shelf: 5 boxes + 5 tags \u00b7 A4 list (9 items) \u00b7 signboard: hours + promo", hasLines: true,
    lines: "IMG_2201  tags: $899 \u00b7 $1,099 \u00b7 $1,299 \u00b7 $1,499 \u00b7 $649\nIMG_2202  A4 list matches stocklist for 9/11 items\nIMG_2203  \"Student promo: $50 off any laptop with matric card\""
  };

  const open = c => ({ ...c, open: true, chev: "rotate(180deg)" });

  const PRODUCTS = [
    { name: "Lenovo IdeaPad Slim 5 14\" \u2014 Ryzen 7 7730U, 16 GB, OLED", price: "$1,099", stock: "3 / 1" },
    { name: "Acer Nitro V 15 \u2014 i5-13420H, RTX 4050, 16 GB", price: "$1,299", stock: "2 / 0" },
    { name: "MacBook Air 13\" M4 \u2014 16 GB, 256 GB, Midnight", price: "$1,499", stock: "2 / 1" },
    { name: "Acer Aspire Go 15 \u2014 i3-N305, 8 GB (display set)", price: "$649", stock: "1 / 0" },
    { name: "Anker 7-in-1 USB-C dock", price: "$89", stock: "6 / 2" },
    { name: "Logitech MX Master 3S", price: "$129", stock: "5 / 3" },
    { name: "Samsung T7 1 TB portable SSD", price: "$139", stock: "12 / 5" },
    { name: "Belkin USB-C cable 2 m 100 W", price: "$29", stock: "30 / 18" },
    { name: "Targus 15.6\" laptop backpack", price: "$59", stock: "7 / 4" },
    { name: "Crucial 16 GB DDR5-5600 SO-DIMM", price: "$79", stock: "8 / 0" }
  ];

  const LOG_B = [
    ok("Shop: Ah Seng Electronics \u00b7 Sim Lim Square"),
    ok("Category: Electronics \u2192 Laptops & accessories"),
    ok("Outlets: Bugis (Sim Lim) \u00b7 Jurong Point"),
    q("Website: Shopify (owner says outdated)")
  ];
  const LOG_C = [...LOG_B,
    ok("11 products from 3 sources (merged)"),
    flag("Vivobook 15: site $949 vs stocklist $899"),
    flag("Signboard promo: $50 off laptops, matric card")
  ];
  const LOG_D = [...LOG_B,
    ok("11 products from 3 sources (merged)"),
    struck("Vivobook 15: site $949 vs stocklist $899"),
    flag("Signboard promo: $50 off laptops, matric card"),
    ok("Source priority: stocklist > shelf photo > Shopify"),
    ok("Vivobook 15 = $899"),
    ok("Promo: \u2212$50 laptops only, needs matric card")
  ];
  const LOG_E = [...LOG_D,
    ok("Warranty: brand 1-yr \u00b7 MacBook = Apple \u00b7 7-day DOA"),
    ok("Services: RAM/SSD upgrades @ Bugis only"),
    ok("Stock transfer Bugis \u2192 Jurong, next day"),
    ok("Aspire Go 15 = display set, last unit")
  ];
  LOG_E[LOG_E.length - 1] = { ...LOG_E[LOG_E.length - 1], tools: true };
  const LOG_F = [...LOG_E, ok("Below-budget: show closest match + explain")];
  const LOG_G = [...LOG_F, ok("Checkout: pay in chat (Visa) \u2192 pickup at outlet")];

  const DROP_A = "Drop a spreadsheet, photos, or paste your store link. Or just tell me about your shop.";
  const DROP_ON = "Drop more files any time \u2014 spreadsheet, photos, store link.";

  const withChev = c => ({ chev: "none", open: false, ...c });

  const base = {
    orbLabel: "Speaking", amp: 1, orbScale: "1", beat: "1.5s", speaking: true, orbAnim: "qbeat", haloAnim: "qhalo", ringAnim: "qring",
    hasCaption: false, captionLabel: "You", caption: "",
    hasPills: false, pills: [],
    log: [], logEmpty: false,
    rightLabel: "Context", cards: [], contextEmpty: false,
    hasListing: false, products: PRODUCTS,
    dropBar: true, dropText: DROP_ON, goLive: false
  };
  const f = o => ({ ...base, ...o, cards: (o.cards || []).map(withChev) });

  return [
    f({
      key: "A", screenLabel: "State A", heading: "State A \u2014 Empty / invite", note: "orb idle, columns empty",
      header: "Idle", orbLabel: "Tap the circle, or just start talking", amp: 0.25, orbScale: "0.9", beat: "3.4s", speaking: false, orbAnim: "none", haloAnim: "none", ringAnim: "none",
      agentLine: "Hi, I'm the agent for electronics shops. Tell me about your shop, or drop anything you have \u2014 a price list, photos of your shelves, your website. I'll do the sorting.",
      logEmpty: true, contextEmpty: true, dropText: DROP_A
    }),
    f({
      key: "B", screenLabel: "State B", heading: "State B \u2014 Owner's brain-dump", note: "listening; decisions fill while he talks",
      header: "Listening", orbLabel: "Listening to you", amp: 0.6, orbScale: "0.97", beat: "0.85s", speaking: false, orbAnim: "qbeat", haloAnim: "qhalo", ringAnim: "qring",
      agentLine: "Got it \u2014 Ah Seng Electronics, laptops and accessories, two counters. Send the stock list and photos whenever you're ready, and paste the Shopify link too even if it's old. I'll cross-check them.",
      hasCaption: true,
      caption: "Okay. My shop is Ah Seng Electronics, we're in Sim Lim Square, third floor. We mainly sell laptops \u2014 ASUS, Lenovo, Acer, some MacBooks \u2014 and the usual accessories, docks, mouse, SSD, bags. We have another counter at Jurong Point. I have a Shopify site but it's not really updated. I'll just send you my stock list and some photos of the shelf.",
      log: LOG_B, contextEmpty: true, dropText: DROP_A
    }),
    f({
      key: "C", screenLabel: "State C", heading: "State C \u2014 Uploads landing", note: "three sources; photos mid-read",
      header: "Reading uploads",
      agentLine: "Reading\u2026 Your spreadsheet has eleven items across the two counters. Your Shopify has six, and it's older \u2014 a few prices don't match. The shelf photos gave me five laptops with tags, and I can see your opening hours and a student promo on the signboard. Let me confirm a few things.",
      log: LOG_C, cards: [CARD_SHEET, CARD_SITE, open(CARD_PHOTOS_READING)]
    }),
    f({
      key: "D", screenLabel: "State D", heading: "State D \u2014 Clarifying round 1", note: "the conflict resolves in the log",
      header: "Confirming",
      agentLine: "Your Vivobook 15 is nine-forty-nine on Shopify but eight-ninety-nine on the shelf and in the stock list. Which one is right?",
      hasCaption: true, caption: "Eight-ninety-nine. The website is old, I never update it.",
      log: LOG_D, cards: [CARD_SHEET, open(CARD_SITE), CARD_PHOTOS_DONE]
    }),
    f({
      key: "E", screenLabel: "State E", heading: "State E \u2014 Category-trained questions", note: "fourth of four exchanges",
      header: "Laptop questions",
      agentLine: "Last one \u2014 the Aspire Go 15 at six-forty-nine. Is that new or a display set?",
      hasCaption: true, caption: "Display set, last unit. Still got warranty.",
      log: LOG_E, cards: [open(CARD_SHEET), CARD_SITE, CARD_PHOTOS_DONE]
    }),
    f({
      key: "F", screenLabel: "State F", heading: "State F \u2014 Behaviour rules", note: "the only tapped answers",
      header: "Two rules",
      agentLine: "And if a shopper wants to reserve or pay, should I let them pay in the chat and pick up, or send them to WhatsApp you?",
      hasPills: true,
      pills: [
        { label: "Pay in chat, pick up at counter", bg: p.accent, fg: p.onAccent, bd: p.accent },
        { label: "WhatsApp me first", bg: "transparent", fg: p.ink, bd: p.line }
      ],
      log: LOG_F, cards: [CARD_SHEET, CARD_SITE, CARD_PHOTOS_DONE]
    }),
    f({
      key: "G", screenLabel: "State G", heading: "State G \u2014 Result and go live", note: "context becomes the listing",
      header: "Ready",
      agentLine: "Done. Eleven products are ready, all readable by the shopping agent. Here's how I'll describe your Vivobook to a shopper.",
      log: LOG_G, rightLabel: "Product listing \u00b7 11 items",
      hasListing: true, dropBar: false, goLive: true
    })
  ];
}
